create package cwm2_olap_mr_session_pop as

procedure pop_mr_session(full_dim_privs varchar2, full_cube_privs varchar2);

end cwm2_olap_mr_session_pop;