create package cwm2_olap_level as

  procedure Create_Level(p_Dimension_Owner varchar2
                        ,p_Dimension_Name varchar2
                        ,p_Level_Name varchar2
                        ,p_Display_Name varchar2
                        ,p_Plural_Name varchar2
                        ,p_Short_Description varchar2
                        ,p_Description varchar2);

  procedure Set_Level_Name(p_Dimension_Owner varchar2
                          ,p_Dimension_Name varchar2
                          ,p_Level_Name varchar2
                          ,p_Set_Level_Name varchar2);

  procedure Set_Display_Name(p_Dimension_Owner varchar2
                            ,p_Dimension_Name varchar2
                            ,p_Level_Name varchar2
                            ,p_Display_Name varchar2);

  procedure Set_Plural_Name(p_Dimension_Owner varchar2
                           ,p_Dimension_Name varchar2
                           ,p_Level_Name varchar2
                           ,p_Plural_Name varchar2);

  procedure Set_Short_Description(p_Dimension_Owner varchar2
                                 ,p_Dimension_Name varchar2
                                 ,p_Level_Name varchar2
                                 ,p_Short_Description varchar2);

  procedure Set_Description(p_Dimension_Owner varchar2
                           ,p_Dimension_Name varchar2
                           ,p_Level_Name varchar2
                           ,p_Description varchar2);

  procedure Add_Level_To_Hierarchy(p_Dimension_Owner varchar2
                                  ,p_Dimension_Name varchar2
                                  ,p_Hierarchy_Name varchar2
                                  ,p_Child_Level_Name varchar2
                                  ,p_Parent_Level_Name varchar2 default null);

  procedure Remove_Level_From_Hierarchy(p_Dimension_Owner varchar2
                                       ,p_Dimension_Name varchar2
                                       ,p_Hierarchy_Name varchar2
                                       ,p_Child_Level_Name varchar2);

  procedure Drop_Level(p_Dimension_Owner varchar2
                      ,p_Dimension_Name varchar2
                      ,p_Level_Name varchar2);

  procedure Lock_Level(p_Dimension_Owner varchar2
                      ,p_Dimension_Name varchar2
                      ,p_Level_Name varchar2
                      ,p_Wait_For_Lock boolean default false);

end cwm2_olap_level;