create package cwm2_olap_level_attribute as

  procedure Create_Level_Attribute(p_Dimension_Owner varchar2
                                  ,P_Dimension_Name varchar2
                                  ,p_Dimension_Attribute_Name varchar2
                                  ,p_Level_Name varchar2
                                  ,p_Level_Attribute_Name varchar2
                                  ,p_Display_Name varchar2
                                  ,p_Short_Description varchar2
                                  ,p_Description varchar2
                                  ,p_Type varchar2);


  procedure Create_Level_Attribute(p_Dimension_Owner varchar2
                                  ,P_Dimension_Name varchar2
                                  ,p_Dimension_Attribute_Name varchar2
                                  ,p_Level_Name varchar2
                                  ,p_Level_Attribute_Name varchar2
                                  ,p_Display_Name varchar2
                                  ,p_Short_Description varchar2
                                  ,p_Description varchar2
                                  ,p_Use_Name_As_Type boolean default FALSE);


  procedure Create_Level_Attribute_2(p_Dimension_Owner varchar2
                                    ,P_Dimension_Name varchar2
                                    ,p_Dimension_Attribute_Name varchar2
                                    ,p_Level_Name varchar2
                                    ,p_Level_Attribute_Name varchar2
                                    ,p_Display_Name varchar2
                                    ,p_Short_Description varchar2
                                    ,p_Description varchar2
                                    ,p_Use_Name_As_Type number);


  procedure Set_Level_Attribute_Name(p_Dimension_Owner varchar2
                                    ,p_Dimension_Name varchar2
                                    ,p_Dimension_Attribute_Name varchar2
                                    ,p_Level_Name varchar2
                                    ,p_Level_Attribute_Name varchar2
                                    ,p_Set_Level_Attribute_Name varchar2
                                    ,p_Type varchar2);


  procedure Set_Level_Attribute_Name(p_Dimension_Owner varchar2
                                    ,p_Dimension_Name varchar2
                                    ,p_Dimension_Attribute_Name varchar2
                                    ,p_Level_Name varchar2
                                    ,p_Level_Attribute_Name varchar2
                                    ,p_Set_Level_Attribute_Name varchar2
                                    ,p_Use_Name_As_Type boolean default FALSE);


  procedure Set_Display_Name(p_Dimension_Owner varchar2
                            ,P_Dimension_Name varchar2
                            ,p_Dimension_Attribute_Name varchar2
                            ,p_Level_Name varchar2
                            ,p_Level_Attribute_Name varchar2
                            ,p_Display_Name varchar2);

  procedure Set_Short_Description(p_Dimension_Owner varchar2
                                 ,p_Dimension_Name varchar2
                                 ,p_Dimension_Attribute_Name varchar2
                                 ,p_Level_Name varchar2
                                 ,p_Level_Attribute_Name varchar2
                                 ,p_Short_Description varchar2);

  procedure Set_Description(p_Dimension_Owner varchar2
                           ,p_Dimension_Name varchar2
                           ,p_Dimension_Attribute_Name varchar2
                           ,p_Level_Name varchar2
                           ,p_Level_Attribute_Name varchar2
                           ,p_Description varchar2);

  procedure Drop_Level_Attribute(p_Dimension_Owner varchar2
                                ,P_Dimension_Name varchar2
                                ,p_Dimension_Attribute_Name varchar2
                                ,p_Level_Name varchar2
                                ,p_Level_Attribute_Name varchar2);

  procedure Lock_Level_Attribute(p_Dimension_Owner varchar2
                                ,P_Dimension_Name varchar2
                                ,p_Dimension_Attribute_Name varchar2
                                ,p_Level_Name varchar2
                                ,p_Level_Attribute_Name varchar2
                                ,p_Wait_For_Lock boolean default false);

end cwm2_olap_level_attribute;