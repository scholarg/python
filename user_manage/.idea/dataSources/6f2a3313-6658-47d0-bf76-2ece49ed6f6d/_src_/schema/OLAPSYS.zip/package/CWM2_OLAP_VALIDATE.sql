create package cwm2_olap_validate as

  procedure Validate_Dimension(p_Dimension_Owner varchar2
                              ,p_Dimension_Name varchar2
                              ,p_Type_Of_Validation varchar2 default 'DEFAULT'
                              ,p_Verbose_Report varchar2     default 'YES'
                              );

  procedure Validate_Cube(p_Cube_Owner varchar2
                         ,p_Cube_Name varchar2
                         ,p_Type_Of_Validation varchar2 default 'DEFAULT'
                         ,p_Verbose_Report varchar2     default 'YES'
                         );

  procedure Validate_All_Dimensions(p_Type_Of_Validation varchar2 default 'DEFAULT'
                                   ,p_Verbose_Report varchar2     default 'YES'
                                   );

  procedure Validate_All_Cubes(p_Type_Of_Validation varchar2 default 'DEFAULT'
                              ,p_Verbose_Report varchar2     default 'YES'
                              );

  procedure Validate_Olap_Catalog(p_Type_Of_Validation varchar2 default 'DEFAULT'
                                 ,p_Verbose_Report varchar2     default 'YES'
                                 );

end cwm2_olap_validate;