create package cwm2_olap_export as

  procedure Export_Dimension(p_Dimension_Owner   varchar2
                            ,p_Dimension_Name    varchar2
                            ,p_Directory_Name    varchar2 default null
                            ,p_Command_File_Name varchar2 default null
                            ,p_Table_File_Name   varchar2 default null
                            );

  procedure Export_Cube(p_Cube_Owner        varchar2
                       ,p_Cube_Name         varchar2
                       ,p_Directory_Name    varchar2 default null
                       ,p_Command_File_Name varchar2 default null
                       ,p_Table_File_Name   varchar2 default null
                       );

  procedure Export_OLAP_Catalog(p_Directory_Name    varchar2 default null
                               ,p_Command_File_Name varchar2 default null
                               ,p_Table_File_Name   varchar2 default null
                               );
end cwm2_olap_export;