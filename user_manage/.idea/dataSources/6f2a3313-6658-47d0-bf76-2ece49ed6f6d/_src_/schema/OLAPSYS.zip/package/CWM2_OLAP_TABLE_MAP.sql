create package cwm2_olap_table_map as

procedure       Add_AWView(p_View_owner varchar2,
                           p_view_name varchar2,
                           p_rowtocell_col_name varchar2 default null,
                           p_awowner varchar2 default null,
                           p_awname varchar2 default null);

procedure       Remove_AWView(p_View_owner varchar2,
                           p_view_name varchar2);

procedure map_awview_column(p_view_owner varchar2, p_view_name varchar2,
                            p_column varchar2,
                            p_awobject varchar2);

procedure       Map_FactTbl_LevelKey(p_Cube_Owner varchar2,
                                     p_Cube_Name varchar2,
                                     p_Facttable_Owner varchar2,
                                     p_Facttable_Name varchar2,
                                     p_Storetype varchar2,
                                     p_Dimkeymap varchar2,
                                     p_Dimktype varchar2 default null);

procedure RemoveMap_FactTbl_LevelKey(p_Cube_Owner varchar2,
                                     p_Cube_Name varchar2,
                                     p_Facttable_Owner varchar2,
                                     p_Facttable_Name varchar2);

procedure       Map_FactTbl_Measure(p_Cube_Owner varchar2,
                                    p_Cube_Name varchar2,
                                    p_Measure_Name varchar2,
                                    p_Facttable_Owner varchar2,
                                    p_Facttable_Name varchar2,
                                    p_Column_Name varchar2,
                                    p_Dimkeymap varchar2);

procedure RemoveMap_FactTbl_Measure(p_Cube_Owner varchar2,
                                    p_Cube_Name varchar2,
                                    p_Measure_Name varchar2,
                                    p_Facttable_Owner varchar2,
                                    p_Facttable_Name varchar2,
                                    p_Column_Name varchar2,
                                    p_Dimkeymap varchar2);

procedure       Map_DimTbl_HierLevel(p_Dimension_Owner varchar2,
                                     p_Dimension_Name varchar2,
                                     p_Hierarchy_Name varchar2,
                                     p_Level_Name varchar2,
                                     p_Table_Owner varchar2,
                                     p_Table_Name varchar2,
                                     P_KeyCol varchar2,
                                     P_ParentCol varchar2 default null);

procedure RemoveMap_DimTbl_HierLevel(p_Dimension_Owner varchar2,
                                     p_Dimension_Name varchar2,
                                     p_Hierarchy_Name varchar2,
                                     p_Level_Name varchar2);

procedure       Map_DimTbl_HierLevelAttr(p_Dimension_Owner varchar2,
                                         p_Dimension_Name varchar2,
                                         p_Dimension_Attribute_Name varchar2,
                                         p_Hierarchy_Name varchar2,
                                         p_Level_Name varchar2,
                                         p_Level_Attribute_Name varchar2,
                                         p_Table_Owner varchar2,
                                         p_Table_Name varchar2,
                                         p_AttrCol varchar2);

procedure RemoveMap_DimTbl_HierLevelAttr(p_Dimension_Owner varchar2,
                                         p_Dimension_Name varchar2,
                                         p_Dimension_Attribute_Name varchar2,
                                         p_Hierarchy_Name varchar2,
                                         p_Level_Name varchar2,
                                         p_Level_Attribute_Name varchar2);

procedure       Map_DimTbl_Level(p_Dimension_Owner varchar2,
                                 p_Dimension_Name varchar2,
                                 p_Level_Name varchar2,
                                 p_Table_Owner varchar2,
                                 p_Table_Name varchar2,
                                 p_KeyCol varchar2);

procedure RemoveMap_DimTbl_Level(p_Dimension_Owner varchar2,
                                 p_Dimension_Name varchar2,
                                 p_Level_Name varchar2);

procedure       Map_DimTbl_LevelAttr(p_Dimension_Owner varchar2,
                                     p_Dimension_Name varchar2,
                                     p_Dimension_Attribute_Name varchar2,
                                     p_Level_Name varchar2,
                                     p_Level_Attribute_Name varchar2,
                                     p_Table_Owner varchar2,
                                     p_Table_Name varchar2,
                                     p_AttrCol varchar2);

procedure RemoveMap_DimTbl_LevelAttr(p_Dimension_Owner varchar2,
                                     p_Dimension_Name varchar2,
                                     p_Dimension_Attribute_Name varchar2,
                                     p_Level_Name varchar2,
                                     p_Level_Attribute_Name varchar2);

procedure       Map_DimTbl_HierSortKey(p_Dimension_Owner varchar2,
                                       p_Dimension_Name varchar2,
                                       p_Hierarchy_Name varchar2,
                                       p_SortCol varchar2);

procedure RemoveMap_DimTbl_HierSortKey(p_Dimension_Owner varchar2,
                                       p_Dimension_Name varchar2,
                                       p_Hierarchy_Name varchar2);

end cwm2_olap_table_map;