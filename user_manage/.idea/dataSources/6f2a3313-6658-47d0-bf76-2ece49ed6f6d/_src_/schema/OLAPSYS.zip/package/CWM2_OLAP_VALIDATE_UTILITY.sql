create package cwm2_olap_validate_utility as
  VALIDATE_VERSION varchar2(6) := '040401';

  procedure Save_Null_Status(p_Entity_IRID number
                            ,p_Entity_Type varchar2
                            ,p_Entity_Comment varchar2 default null
                            );

  procedure Save_Valid_Status(p_Entity_IRID number
                             ,p_Entity_Type varchar2
                             ,p_Entity_Name OLAPSYS.CwM2$OLAPValidateTable%rowtype
                             ,p_Entity_Comment varchar2 default null
                             ,p_Verbose_Report varchar2 default 'NO'
                             );

  procedure Save_Invalid_Status(p_Entity_IRID number
                               ,p_Entity_Type varchar2
                               ,p_Entity_Name OLAPSYS.CwM2$OLAPValidateTable%rowtype
                               ,p_Entity_Comment varchar2 default null
                               );

  procedure Save_Note_Status(p_Entity_IRID number
                            ,p_Entity_Type varchar2
                            ,p_Entity_Name OLAPSYS.CwM2$OLAPValidateTable%rowtype
                            ,p_Entity_Comment varchar2 default null
                            );

  procedure Init_Validate(p_Verbose_Report varchar2
                         );

  procedure Report_Validate;

end cwm2_olap_validate_utility;