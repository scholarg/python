create package cwm2_olap_catalog as

  procedure Create_Catalog(p_Catalog_Name varchar2
                          ,p_Description varchar2
                          ,p_Parent_Catalog_Name varchar2 default null);

  procedure Set_Catalog_Name(p_Catalog_Name varchar2
                            ,p_Set_Catalog_Name varchar2);

  procedure Set_Description(p_Catalog_Name varchar2
                           ,p_Description varchar2);

  procedure Set_Parent_Catalog(p_Catalog_Name varchar2
                              ,p_Parent_Catalog_Name varchar2 default null);

  procedure Drop_Catalog(p_catalog_Name varchar2,
                         p_Silent varchar2 default null);

  procedure Lock_Catalog(p_Catalog_Name varchar2
                        ,p_Wait_For_Lock boolean default false);

  procedure Add_Catalog_Entity(p_Catalog_Name varchar2
                              ,p_Cube_Owner varchar2
                              ,p_Cube_Name varchar2
                              ,p_Measure_Name varchar2);

  procedure Remove_Catalog_Entity(p_Catalog_Name varchar2
                                 ,p_Cube_Owner varchar2
                                 ,p_Cube_Name varchar2
                                 ,p_Measure_Name varchar2);

end cwm2_olap_catalog;
