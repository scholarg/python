create PACKAGE DBMS_ODM AUTHID CURRENT_USER AS

PROCEDURE CreateDimLevTuple(p_Cube_Owner IN varchar2
                           ,p_Cube_Name  IN varchar2
                            );

PROCEDURE CreateDimLevTuple(p_Cube_Owner         IN varchar2
                           ,p_Cube_Name          IN varchar2
                           ,p_Levels_Table_Owner IN varchar2
                           ,p_Levels_Table_Name  IN varchar2
                            );

-- levels table: CREATE TABLE <schema>.<table> of SYS.OlapLevel ...


PROCEDURE CreateCubeLevelTuple(p_Cube_Owner IN varchar2
                              ,p_Cube_Name  IN varchar2
                               );

PROCEDURE CreateCubeLevelTuple(p_Cube_Owner         IN varchar2
                              ,p_Cube_Name          IN varchar2
                              ,p_Levels_Table_Owner IN varchar2
                              ,p_Levels_Table_Name  IN varchar2
                              ,p_Tuples_Table_Owner IN varchar2
                              ,p_Tuples_Table_Name  IN varchar2
                               );

-- tuples table: CREATE TABLE <schema>.<table> of SYS.OlapLevelTuple ...


PROCEDURE CreateDimMV_GS(p_Dimension_Owner  IN varchar2
                        ,p_Dimension_Name   IN varchar2
                        ,p_Output_File      IN varchar2
                        ,p_Output_Path      IN varchar2
                        ,p_Tablespace_MV    IN varchar2 default null
                        ,p_Tablespace_Index IN varchar2 default null
                         );

PROCEDURE CreateDimMV_GS(p_Dimension_Owner  IN varchar2
                        ,p_Dimension_Name   IN varchar2
                        ,p_Output_File      IN varchar2
                        ,p_Output_Path      IN varchar2
                        ,p_Partitioning     IN boolean
                        ,p_Tablespace_MV    IN varchar2
                        ,p_Tablespace_Index IN varchar2
                         );



PROCEDURE CreateDimMV_GS(p_Dimension_Owner  IN varchar2
                        ,p_Dimension_Name   IN varchar2
                        ,p_Output_File      IN varchar2
                        ,p_Output_Path      IN varchar2
                        ,p_Partitioning     IN boolean
                        ,p_Tablespace_MV    IN varchar2
                        ,p_Tablespace_Index IN varchar2
                        ,p_Refresh_Method   IN varchar2  -- 'FORCE', 'FAST, 'COMPLETE'
                        ,p_Refresh_On       IN varchar2  -- 'DEMAND', 'COMMIT'
                        ,p_Execute          IN boolean
                         );



PROCEDURE CreateFactMV_GS(p_Cube_Owner       IN varchar2
                         ,p_Cube_Name        IN varchar2
                         ,p_Output_File      IN varchar2
                         ,p_Output_Path      IN varchar2
                         ,p_Partitioning     IN boolean
                         ,p_Tablespace_MV    IN varchar2 default null
                         ,p_Tablespace_Index IN varchar2 default null
                          );

PROCEDURE CreateFactMV_GS(p_Cube_Owner         IN varchar2
                         ,p_Cube_Name          IN varchar2
                         ,p_Output_File        IN varchar2
                         ,p_Output_Path        IN varchar2
                         ,p_Tuples_Table_Owner IN varchar2
                         ,p_Tuples_Table_Name  IN varchar2
                         ,p_Partitioning       IN boolean
                         ,p_Tablespace_MV      IN varchar2
                         ,p_Tablespace_Index   IN varchar2
                         ,p_Refresh_Method     IN varchar2  -- 'FORCE', 'FAST, 'COMPLETE'
                         ,p_Refresh_On         IN varchar2  -- 'DEMAND', 'COMMIT'
                         ,p_Execute            IN boolean
                          );



PROCEDURE CreateStdFactMV(p_Cube_Owner            IN varchar2
                         ,p_Cube_Name             IN varchar2
                         ,p_Output_File           IN varchar2
                         ,p_Output_Path           IN varchar2
                         ,p_Partitioning          IN boolean
                         ,p_Materialization_Level IN varchar2
                         ,p_Materialization_Pct   IN number   default null
                         ,p_Tablespace_MV         IN varchar2 default null
                         ,p_Tablespace_Index      IN varchar2 default null
                          );


PROCEDURE CreateStdFactMV(p_Cube_Owner            IN varchar2
                         ,p_Cube_Name             IN varchar2
                         ,p_Output_File           IN varchar2
                         ,p_Output_Path           IN varchar2
                         ,p_Partitioning          IN boolean
                         ,p_Materialization_Level IN varchar2
                         ,p_Materialization_Pct   IN number
                         ,p_Tablespace_MV         IN varchar2
                         ,p_Tablespace_Index      IN varchar2
                         ,p_Refresh_Method        IN varchar2  -- 'FORCE', 'FAST, 'COMPLETE'
                         ,p_Refresh_On            IN varchar2  -- 'DEMAND', 'COMMIT'
                         ,p_Execute               IN boolean
                          );


PROCEDURE ODM_VERSION;

FUNCTION ODMVERSION return varchar2;

PROCEDURE CreateDimOWB(p_Run_ID           IN number
                      ,p_Dimension_Owner  IN varchar2
                      ,p_Dimension_Name   IN varchar2
                       );

PROCEDURE CreateDimOWB(p_Run_ID           IN number
                      ,p_Dimension_Owner  IN varchar2
                      ,p_Dimension_Name   IN varchar2
                      ,p_Partitioning     IN boolean
                      ,p_Tablespace_MV    IN varchar2
                      ,p_Tablespace_Index IN varchar2
                      ,p_Refresh_Method   IN varchar2  -- 'FORCE', 'FAST, 'COMPLETE'
                      ,p_Refresh_On       IN varchar2  -- 'DEMAND', 'COMMIT'
                      ,p_Execute          IN boolean
                       );



PROCEDURE CreateFactOWB(p_Run_ID     IN number
                       ,p_Cube_Owner IN varchar2
                       ,p_Cube_Name  IN varchar2
                        );

PROCEDURE CreateFactOWB(p_Run_ID             IN number
                       ,p_Cube_Owner         IN varchar2
                       ,p_Cube_Name          IN varchar2
                       ,p_Tuples_Table_Owner IN varchar2
                       ,p_Tuples_Table_Name  IN varchar2
                       ,p_Partitioning       IN boolean
                       ,p_Tablespace_MV      IN varchar2
                       ,p_Tablespace_Index   IN varchar2
                       ,p_Refresh_Method     IN varchar2 -- 'FORCE', 'FAST, 'COMPLETE'
                       ,p_Refresh_On         IN varchar2 -- 'DEMAND', 'COMMIT'
                       ,p_Execute            IN boolean
                        );



PROCEDURE CreateStdFactMVOWB(p_Run_ID                IN number
                            ,p_Cube_Owner            IN varchar2
                            ,p_Cube_Name             IN varchar2
                            ,p_Materialization_Level IN varchar2
                            ,p_Materialization_Pct   IN number   default null
                             );

PROCEDURE CreateStdFactMVOWB(p_Run_ID                IN number
                            ,p_Cube_Owner            IN varchar2
                            ,p_Cube_Name             IN varchar2
                            ,p_Partitioning          IN boolean
                            ,p_Materialization_Level IN varchar2
                            ,p_Materialization_Pct   IN number
                            ,p_Tablespace_MV         IN varchar2
                            ,p_Tablespace_Index      IN varchar2
                            ,p_Refresh_Method        IN varchar2  -- 'FORCE', 'FAST, 'COMPLETE'
                            ,p_Refresh_On            IN varchar2  -- 'DEMAND', 'COMMIT'
                            ,p_Execute               IN boolean
                             );


/* deprecated  04/08/26
PROCEDURE CreateCubeLevelTuple(p_Cube_Owner             IN varchar2
                              ,p_Cube_Name              IN varchar2
                              ,p_Levels                 IN SYS.OlapLevels
                              ,p_Number_Of_Level_Tuples IN OUT NUMBER
                              ,p_Olaplevel_Tuples       OUT SYS.OlapLevelTuples
                               );
*/


/* deprecated  04/08/25
PROCEDURE CreateDimMV_GS(p_Run_ID         IN NUMBER
                        ,p_Cube_Owner     IN varchar2
                        ,p_Dimension_Name IN varchar2
                         );
*/


/* deprecated  04/08/25
PROCEDURE CreateFactMV_GS(p_Run_ID                 IN NUMBER
                         ,p_Cube_Owner             IN varchar2
                         ,p_Cube_Name              IN varchar2
                         ,p_Partitioning           IN BOOLEAN
                         ,p_Tablespace_MV          IN varchar2
                         ,p_Tablespace_Index       IN varchar2
                         ,p_Outscript              OUT CLOB
                         ,p_Number_Of_Level_Tuples IN NUMBER              default null
                         ,p_Level_Tuples           IN SYS.OlapLevelTuples default null
                          );
*/

END;