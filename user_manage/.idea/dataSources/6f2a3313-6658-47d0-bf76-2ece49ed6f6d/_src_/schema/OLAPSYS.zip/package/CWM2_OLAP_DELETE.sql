create package cwm2_olap_delete as

  procedure Delete_Dimension(p_Dimension_Owner       varchar2
                            ,p_Dimension_Name        varchar2
                            ,p_Delete_CWM1_Dimension varchar2
                            ,p_Report                varchar2
                            ,p_Delete                varchar2
                            );

  procedure Delete_Cube(p_Cube_Owner varchar2
                       ,p_Cube_Name  varchar2
                       ,p_Report     varchar2
                       ,p_Delete     varchar2
                       );

  procedure Delete_Measure_Catalog(p_Measure_Catalog_Name varchar2
                                  ,p_Report               varchar2
                                  ,p_Delete               varchar2
                                  );

  procedure Delete_OLAP_Catalog(p_Delete_CWM1_Dimension varchar2
                               ,p_Report                varchar2
                               ,p_Delete                varchar2
                               );

end cwm2_olap_delete;