create trigger CWM2$MEASUREDEL
	before delete
	on CWM2$MEASURE
	for each row
declare
  begin
    delete  from olapsys.CwM2$AWCubeLoadMeasure
      where IRID in (select  clm.IRID
                       from  CwM2$AWCubeLoad cl
                            ,CwM2$AWCubeLoadMeasure clm
                       where cl.IRID          = clm.CubeLoad_IRID
                       and   cl.Version_ID    = 'CWM2'
                       and   clm.Measure_IRID = :old.irid);
  end;