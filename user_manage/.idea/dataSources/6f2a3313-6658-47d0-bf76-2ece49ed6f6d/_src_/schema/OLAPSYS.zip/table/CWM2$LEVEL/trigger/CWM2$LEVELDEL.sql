create trigger CWM2$LEVELDEL
	before delete
	on CWM2$LEVEL
	for each row
declare
  begin
    delete  from olapsys.CwM2$AWCubeAggLevel
      where IRID in (select  cal.IRID
                       from  CwM2$AWCubeAgg ca
                            ,CwM2$AWCubeAggLevel cal
                       where ca.IRID        = cal.CubeAgg_IRID
                       and   ca.Version_ID  = 'CWM2'
                       and   cal.Level_IRID = :old.irid);
  end;