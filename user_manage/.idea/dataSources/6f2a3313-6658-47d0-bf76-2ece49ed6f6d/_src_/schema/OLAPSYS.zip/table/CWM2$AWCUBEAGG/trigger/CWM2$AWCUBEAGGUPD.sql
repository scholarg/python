create trigger CWM2$AWCUBEAGGUPD
	before insert or update
	on CWM2$AWCUBEAGG
	for each row
declare
    v_User_Name varchar2(30);
  begin
    select USER into v_User_Name from dual;
    if inserting then
      :new.CreatedDate := SYSDATE;
      :new.UpdatedDate := null;
    else
      :new.UpdatedDate := SYSDATE;
    end if;
    :new.LastChangeUser := v_User_Name;
  end;