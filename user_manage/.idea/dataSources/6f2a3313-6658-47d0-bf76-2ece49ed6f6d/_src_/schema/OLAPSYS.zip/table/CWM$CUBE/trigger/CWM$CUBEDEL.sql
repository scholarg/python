create trigger CWM$CUBEDEL
	before delete
	on CWM$CUBE
	for each row
declare
  begin
    delete from olapsys.CwM2$AWCubeLoad
      where Cube_IRID  = :old.irid
      and   Version_ID = 'CWM';
    delete from olapsys.CwM2$AWCompositeSpec
      where Cube_IRID  = :old.irid
      and   Version_ID = 'CWM';
    delete from olapsys.CwM2$AWCubeAgg
      where Cube_IRID  = :old.irid
      and   Version_ID = 'CWM';
 end;