create view ALL$OLAP_CUBES as
SELECT
  sch.physicalname owner
, cub.physicalname cube_name
, cwm$util.cube_invalid(cub.irid) invalid
, cub.displayname display_name
, cub.description description
FROM
  dba_users u
, cwm$model sch
, cwm$cube  cub
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND (    cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
WITH READ ONLY
