create view DBA$OLAP2_AWVIEWCOLS as
select
awv.view_owner view_owner,
awv.view_name view_name,
col.name column_name,
awvc.awobject awobject
from olapsys.cwm2$awviews awv,
     olapsys.cwm2$awviewcols awvc,
     sys.col$ col
where awvc.awviews_irid = awv.irid and
      awv.table_id = col.obj# and
      awvc.column_id = col.col#
with read only
