create view ALL$AW_LOAD_CUBE_DIMS as
select cub2.owner cube_owner,
         cub2.name cube_name,
         cl.name cubeload_name,
         cs.name compspec_name,
         csmCOM.name composite_name,
         csmCOM.segwidth segwidth,
         csmCOM.compspec_position compspec_position,
         dim2.owner dimension_owner,
         dim2.name dimension_name,
         csmMEM.composite_position composite_position,
         csmCOM.composite_level+1 nested_level,
         csmMEM.membertype nested_type,
         csmMEM.name nested_name
  from cwm2$cube cub2,
       cwm2$awcubeload cl,
       cwm2$awcubecompplan ccp,
       cwm2$awcompositeSpec cs,
       (select level composite_level,
               IRID,
               CompSpec_IRID,
               MemberType,
               Name,
               SegWidth,
               CompSpec_Position,
               Dim_IRID,
               Composite_IRID,
               Composite_Position
          from cwm2$awcompspecmembership
          start with membertype = 'COMPOSITE'
            and      composite_irid is null
          connect by composite_irid = prior irid
       ) csmCOM, -- composite
       cwm2$awcompspecmembership csmMEM, -- member
       cwm2$dimension dim2
  where cl.cube_irid = cub2.irid and
       cl.version_id = 'CWM2' and
       (cub2.invalid = 'N' or cub2.invalid = 'O') and
       ccp.cubecompspec_irid = cs.irid and
       ccp.cubeload_irid = cl.irid and
       csmCOM.compspec_irid = cs.irid and
       csmMEM.composite_irid = csmCOM.irid and
       csmMEM.dim_irid = dim2.irid(+) and
       (cwm2$security.fact_table_visible(cub2.irid) = 'Y'
          OR EXISTS (select null from v$enabledprivs
                     where priv_number in (-47)))
 union all
   /* For 9i2 - Get Dimensions outside composite next */
  select cub2.owner cube_owner,
         cub2.name cube_name,
         cl.name cubeload_name,
         cs.name compspec_name,
         NULL composite_name,
         csm.segwidth segwidth,
         csm.compspec_position compspec_position,
         dim2.owner dimension_owner,
         dim2.name dimension_name,
         null composite_position,
         null nested_level,
         null nested_type,
         null nested_name
  from cwm2$cube cub2,
       cwm2$awcubeload cl,
       cwm2$awcubecompplan ccp,
       cwm2$awcompositespec cs,
       cwm2$awcompspecmembership csm,
       cwm2$dimension dim2
  where cl.cube_irid = cub2.irid and
        cl.version_id = 'CWM2' and
        (cub2.invalid = 'N' or cub2.invalid = 'O') and
        ccp.cubecompspec_irid = cs.irid and
        ccp.cubeload_irid = cl.irid and
        csm.compspec_irid = cs.irid and
        csm.membertype = 'DIMENSION' and
        csm.composite_irid is null and
        csm.dim_IRID = dim2.irid and
        (cwm2$security.fact_table_visible(cub2.irid) = 'Y'
          OR EXISTS (select null from v$enabledprivs
                     where priv_number in (-47)))
  union all
  /* For 9i1 - Get Dimensions within a composite */
 select sch.physicalname cube_owner,
        cub1.name cube_name,
        cl.name cubeload_name,
        cs.name compspec_name,
        csmCOM.name composite_name,
        csmCOM.segwidth segwidth,
        csmCOM.compspec_position compspec_position,
        u.username dimension_owner,
        dim1.name dimension_name,
        csmMEM.composite_position composite_position,
        csmCOM.composite_level+1 nested_level,
        csmMEM.membertype nested_type,
        csmMEM.name nested_name
 from cwm$cube cub1,
      cwm2$awcubeload cl,
      cwm2$awcubecompplan ccp,
      cwm2$awcompositeSpec cs,
      (select level composite_level,
              IRID,
              CompSpec_IRID,
              MemberType,
              Name,
              SegWidth,
              CompSpec_Position,
              Dim_IRID,
              Composite_IRID,
              Composite_Position
         from cwm2$awcompspecmembership
         start with membertype = 'COMPOSITE'
           and      composite_irid is null
         connect by composite_irid = prior irid
      ) csmCOM, -- composite
      cwm2$awcompspecmembership csmMEM, -- member
      cwm$dimension dim1,
      sys.dim$ d,
      sys.obj$ o,
      dba_users u,
      cwm$model sch
 where cl.cube_irid = cub1.irid and
       cl.version_id = 'CWM' and
       ccp.cubecompspec_irid = cs.irid and
       ccp.cubeload_irid = cl.irid and
       csmCOM.compspec_irid = cs.irid and
       csmMEM.composite_irid = csmCOM.irid and
       csmMEM.dim_irid = dim1.irid(+) and
       d.obj# = dim1.irid and
       o.obj# = d.obj# and
       u.user_id = o.owner# and
       sch.irid = cub1.datamodel_irid and
       (cwm$util.fact_table_visible(cub1.irid) = 'Y'
          OR EXISTS (select null from v$enabledprivs
                     where priv_number in (-47)))
  union all
   /* For 9i1 - Get Dimensions outside composite next */
  select sch.physicalname cube_owner ,
         cub1.physicalname cube_name,
         cl.name cubeload_name,
         cs.name compspec_name,
         NULL composite_name,
         csm.segwidth segwidth,
         csm.compspec_position compspec_position,
         u.username dimension_owner,
         dim1.name dimension_name,
         null composite_position,
         null nested_level,
         null nested_type,
         null nested_name
  from cwm$cube cub1,
       cwm2$awcubeload cl,
       cwm2$awcubecompplan ccp,
       cwm2$awcompositespec cs,
       cwm2$awcompspecmembership csm,
       cwm$dimension dim1,
       sys.dim$ d,
       sys.obj$ o,
       dba_users u,
       cwm$model sch
  where cl.cube_irid = cub1.irid and
        cl.version_id = 'CWM' and
        ccp.cubecompspec_irid = cs.irid and
        ccp.cubeload_irid = cl.irid and
        csm.compspec_irid = cs.irid and
        csm.membertype = 'DIMENSION' and
        csm.composite_irid is null and
        csm.dim_IRID = dim1.irid and
        d.obj# = dim1.irid and
        o.obj# = d.obj# and
        u.user_id = o.owner# and
        sch.irid = cub1.datamodel_irid and
        (cwm$util.fact_table_visible(cub1.irid) = 'Y'
           OR EXISTS (select null from v$enabledprivs
                      where priv_number in (-47)))
with read only
