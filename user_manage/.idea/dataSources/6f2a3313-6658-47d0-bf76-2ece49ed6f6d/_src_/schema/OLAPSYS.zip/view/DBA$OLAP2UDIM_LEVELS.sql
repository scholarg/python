create view DBA$OLAP2UDIM_LEVELS as
select dl.owner owner,
       dl.dimension_name dimension_name,
       dl.level_name level_name,
       dl.display_name display_name,
       dl.short_description short_description,
       dl.long_description description,
       dl.level_table_owner level_table_owner,
       dl.level_table_name level_table_name
from
(SELECT
  u.username owner
, d.name dimension_name
, l.levelname level_name
, lev.displayname display_name
, lev.description short_description
, lev.description long_description
, tu.username level_table_owner
, t.name level_table_name
FROM
  dba_users u
, sys.obj$ d
, sys.dimlevel$ l
, sys.dimlevelkey$ k
, sys.obj$ t
, dba_users tu
, cwm$level lev
WHERE d.type# = 43 /* DIMENSION */
AND u.user_id = d.owner#
AND d.obj# = l.dimobj#
AND l.dimobj# = k.dimobj#
AND l.levelid# = k.levelid#
AND k.detailobj# = t.obj#
AND t.owner# = tu.user_id
AND k.keypos# = 1
AND l.dimobj# = lev.dimension_irid
AND l.levelname = lev.physicalname (+)) dl
union all
select owner, dimension_name, level_name, display_name, short_description,
       description, null level_table_owner, null level_table_name
from olapsys.dba$olap2_dim_levels
with read only
