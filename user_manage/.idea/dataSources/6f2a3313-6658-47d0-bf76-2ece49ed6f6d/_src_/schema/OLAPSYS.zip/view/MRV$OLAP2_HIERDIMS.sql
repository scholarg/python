create view MRV$OLAP2_HIERDIMS as
select
  hd.owner owner,
  hd.dimension_name dimension_name,
  hd.plural_name plural_name,
  hd.display_name display_name,
  hd.shortdescription short_description,
  hd.description description,
  hd.default_display_hierarchy default_display_hierarchy,
  hd.descriptor_value descriptor_value
 from olapsys.cwm2$mrall_hierdims hd,
      olapsys.olap_session_objects oso
 where oso.version_id = hd.version_id and
       oso.id = hd.id
