create view ALL$OLAP_KEY_COLUMN_USES as
SELECT
/*+ ORDERED */
  u.username owner
, t.name table_name
, c.name key_name
, col.name column_name
, ccol.pos# position
FROM
  dba_users u
, sys.obj$ t
, sys.con$ c
, sys.cdef$ cd
, sys.col$ col
, sys.ccol$ ccol
WHERE u.user_id = c.owner#
AND c.con# = cd.con#
AND cd.con# = ccol.con#
AND cd.obj# = t.obj#
AND ccol.intcol# = col.intcol#
AND col.obj# = t.obj#
AND cd.type# IN (2,3,4) /* primary, unique, referential */
AND t.type# IN (2,4) /* table, view */
AND (   t.owner# = UID
     OR t.obj# IN
       (SELECT obj# FROM sys.objauth$
        WHERE (   grantee# = UID
               OR grantee# IN
                 (SELECT privilege#
                  FROM sys.sysauth$
                  WHERE privilege# > 0
                  START WITH grantee# = UID
                  CONNECT BY PRIOR privilege# = grantee#)))
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
WITH READ ONLY
