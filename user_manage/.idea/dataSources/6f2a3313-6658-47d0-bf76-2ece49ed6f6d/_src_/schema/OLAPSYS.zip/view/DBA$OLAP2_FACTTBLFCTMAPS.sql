create view DBA$OLAP2_FACTTBLFCTMAPS as
select cmm.owner owner,
 cmm.cube_name cube_name,
 cmm.measure_name measure_name,
 cmm.dim_hier_combo_id dim_hier_combo_id,
 cmm.fact_table_owner fact_table_owner,
 cmm.fact_table_name fact_table_name,
 cmm.column_name column_name,
 c.data_type data_type,
 c.data_length data_length,
 c.data_precision data_precision,
 (case when c.data_type = 'NUMBER' then 0
       when c.data_type = 'DOUBLE' then 5
       when c.data_type = 'FLOAT' then 4
       when c.data_type = 'DATE' then 7
       when c.data_type = 'LONG' then 3
       else 1 end) olap_api_data_type
from olapsys.dba$olap2_cube_measure_maps cmm,
     dba_olap_columns c
where
 cmm.fact_table_owner = c.owner
 and cmm.fact_table_name = c.table_name
 and cmm.column_name = c.column_name
