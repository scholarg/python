create view MRV$OLAP2_DIM_HIERS as
select
  dh.owner owner,
  dh.dimension_name dimension_name,
  dh.hierarchy_name hierarchy_name,
  dh.display_name display_name,
  dh.shortdescription short_description,
  dh.description description,
  dh.solved_code solved_code,
  dh.is_default is_default
 from olapsys.cwm2$mrall_dim_hiers dh,
      olapsys.olap_session_objects oso
 where oso.version_id = dh.version_id and
       oso.id = dh.id
