create view EXPORT2_JOIN_KEY_COLUMN_USES as
select
  d.owner owner,
  d.name dimension_name,
--  (case when h.hidden = 'Y'
--        then null else h.name end) hierarchy_name,
  h.name hierarchy_name,
  l.name child_level_name,
  u.username table_owner,
  o.name table_name,
  ck.name key_column_name,
  cf.name foreign_key_column_name,
  dhlm.position position,
  null join_key_type /* join key type */
from olapsys.CwM2$dimension d,
     olapsys.CwM2$hierarchy h,
     olapsys.CwM2$level l,
     olapsys.CwM2$HierLevelRel hlr,
     olapsys.CwM2$DimHierLvlMap dhlm,
     dba_users u,
     sys.obj$ o,
     sys.col$ ck,
     sys.col$ cf
where h.dimension_irid = d.irid and
      h.irid = hlr.hierarchy_irid and
      l.irid = hlr.childlevel_irid and
      dhlm.DimHierLvl_IRID = hlr.irid and
      dhlm.object_ID = o.obj# and
      dhlm.column_id = ck.col# and
      dhlm.object_ID = ck.obj# and
      dhlm.parentcolumn_id = cf.col#(+) and
      dhlm.object_ID = cf.obj#(+) and
      o.owner# = u.user_id
--    dhlm.style = 'STAR'
UNION
select d.owner owner,
  d.name dimension_name,
--  (case when h.hidden = 'Y'
--        then null else h.name end) hierarchy_name,
  h.name hierarchy_name,
  l.name child_level_name,
  u.username table_owner,
  o.name table_name,
  ck.name key_column_name,
  cf.name foreign_key_column_name,
  dhlm.position position,
  null join_key_type /* join key type */
from olapsys.CwM2$dimension d,
     olapsys.CwM2$hierarchy h,
     olapsys.CwM2$level l,
     olapsys.CwM2$HierLevelRel hlr,
     olapsys.CwM2$DimHierLvlMap dhlm,
     dba_users u,
     sys.obj$ o,
     sys.col$ ck,
     sys.col$ cf
where h.dimension_irid = d.irid and
      h.irid = hlr.hierarchy_irid and
      l.irid = hlr.childlevel_irid and
      dhlm.DimHierLvl_IRID = hlr.irid and
      dhlm.object_ID = o.obj# and
      dhlm.column_id = ck.col#(+) and
      dhlm.object_ID = ck.obj#(+) and
      dhlm.parentcolumn_id = cf.col# and
      dhlm.object_ID = cf.obj# and
      o.owner# = u.user_id
--    dhlm.style = 'SNOWFLAKE'
with read only
