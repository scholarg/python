create view ALL$OLAP_CUBE_MEASURE_DIM_USES as
SELECT
  sch.physicalname owner
, cub.physicalname cube_name
, msr.physicalname measure_name
, cdu.dimension_owner
, cdu.dimension_name
, cdu.name dimension_alias
, fu.irid default_aggr_function_use_id
FROM
  dba_users u
, cwm$model sch
, cwm$cube cub
, cwm$measure msr
, cwm$measuredimensionuse mdu
, cwm$cubedimensionuse cdu
, cwm$functionuse fu
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND (    cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
AND cub.irid = msr.itemcontainer_irid
AND msr.irid = mdu.measure_irid
AND mdu.cubedimensionuse_irid = cdu.irid
AND mdu.irid = fu.measuredimensionuse_irid (+)
WITH READ ONLY
