create view ALL$OLAP2_CATALOGS as
select
 c.irid catalog_id,
 c.name catalog_name,
 cp.irid parent_catalog_id,
 c.description description
from
 cwm$classification c,
 cwm$classification cp,
 cwm$classificationtype cty,
 cwm$classificationentry ce
where cty.irid = c.classificationtype_irid and
      cty.name = 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.element_irid and
      ce.name = 'CATALOG2' and
      ce.classification_irid = cp.irid
UNION ALL select
 c.irid catalog_id,
 c.name catalog_name,
 null parent_catalog_id,
 c.description description
from
 cwm$classification c,
 cwm$classificationtype cty
where cty.irid = c.classificationtype_irid and
      cty.name = 'ORACLE_OLAP2_CATALOG' and
      NOT EXISTS
       (select null from cwm$classificationentry ce
        where ce.name = 'CATALOG2' and
              ce.element_irid = c.irid)
with read only
