create view DBA$OLAP2UHIER_CUSTOM_SORT as
select u.username owner,
       o.name dimension_name,
       h.hiername hierarchy_name,
       tu.username table_owner,
       tn.name table_name,
       c.name column_name,
       hcs.position position,
       hcs.sortpos sort_pos,
       hcs.sortorder sort_order,
       hcs.nullorder null_order,
 decode(c.type#, 1, decode(c.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                 2, decode(c.scale, null,
                           decode(c.precision#, null, 'NUMBER', 'FLOAT'),
                           'NUMBER'),
                 8, 'LONG',
                 9, decode(c.charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                 12, 'DATE', 23, 'RAW', 24, 'LONG RAW',
                 69, 'ROWID',
                 96, decode(c.charsetform, 2, 'NCHAR', 'CHAR'),
                 105, 'MLSLABEL',
                 106, 'MLSLABEL',
                 112, decode(c.charsetform, 2, 'NCLOB', 'CLOB'),
                 113, 'BLOB', 114, 'BFILE', 115, 'CFILE',
                 178, 'TIME(' ||c.spare1|| ')',
                 179, 'TIME(' ||c.spare1|| ')' || ' WITH TIME ZONE',
                 180, 'TIMESTAMP(' ||c.spare1|| ')',
                 181, 'TIMESTAMP(' ||c.spare1|| ')' || ' WITH TIME ZONE',
                 182, 'INTERVAL YEAR(' ||c.spare2||') TO MONTH',
                 183, 'INTERVAL DAY(' ||c.spare2||') TO SECOND(' ||
                       c.spare1 || ')',
                 208, 'UROWID',
                 'UNDEFINED') data_type
, decode(c.length, null, 0, c.length) data_length
, decode(c.precision#, null, 0, c.precision#) data_precision
from
  dba_users u,
  sys.obj$ o,
  sys.dim$ d,
  sys.hier$ h,
  cwm2$hiercustomsort hcs,
  dba_users tu,
  sys.obj$ tn,
  sys.col$ c
where
  u.user_id = o.owner# and
  o.type# = 43 and
  o.obj# = d.obj# and
  d.obj# = h.dimobj# and
  hcs.dimension_irid = d.obj# and
  hcs.hier_irid = h.hierid# and
  hcs.metadataversion = 'ONE' and
  hcs.tablename_id = tn.obj# and
  tu.user_id = tn.owner# and
  c.obj# = tn.obj# and
  c.col# = hcs.columnname_id
union
select u.username owner,
       o.name dimension_name,
       null hierarchy_name,
       tu.username table_owner,
       tn.name table_name,
       c.name column_name,
       hcs.position position,
       hcs.sortpos sort_pos,
       hcs.sortorder sort_order,
       hcs.nullorder null_order,
 decode(c.type#, 1, decode(c.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                 2, decode(c.scale, null,
                           decode(c.precision#, null, 'NUMBER', 'FLOAT'),
                           'NUMBER'),
                 8, 'LONG',
                 9, decode(c.charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                 12, 'DATE', 23, 'RAW', 24, 'LONG RAW',
                 69, 'ROWID',
                 96, decode(c.charsetform, 2, 'NCHAR', 'CHAR'),
                 105, 'MLSLABEL',
                 106, 'MLSLABEL',
                 112, decode(c.charsetform, 2, 'NCLOB', 'CLOB'),
                 113, 'BLOB', 114, 'BFILE', 115, 'CFILE',
                 178, 'TIME(' ||c.spare1|| ')',
                 179, 'TIME(' ||c.spare1|| ')' || ' WITH TIME ZONE',
                 180, 'TIMESTAMP(' ||c.spare1|| ')',
                 181, 'TIMESTAMP(' ||c.spare1|| ')' || ' WITH TIME ZONE',
                 182, 'INTERVAL YEAR(' ||c.spare2||') TO MONTH',
                 183, 'INTERVAL DAY(' ||c.spare2||') TO SECOND(' ||
                       c.spare1 || ')',
                 208, 'UROWID',
                 'UNDEFINED') data_type
, decode(c.length, null, 0, c.length) data_length
, decode(c.precision#, null, 0, c.precision#) data_precision
from
  dba_users u,
  sys.obj$ o,
  sys.dim$ d,
  cwm2$hiercustomsort hcs,
  dba_users tu,
  sys.obj$ tn,
  sys.col$ c
where
  u.user_id = o.owner# and
  o.type# = 43 and
  o.obj# = d.obj# and
  hcs.dimension_irid = d.obj# and
  hcs.metadataversion = 'ONE' and
  hcs.tablename_id = tn.obj# and
  tu.user_id = tn.owner# and
  c.obj# = tn.obj# and
  c.col# = hcs.columnname_id
union all
select owner,
       dimension_name,
       hierarchy_name,
       table_owner,
       table_name,
       column_name,
       position,
       sort_pos,
       sort_order,
       null_order,
       data_type,
       data_length,
       data_precision
from dba$olap2_hier_custom_sort
with read only
