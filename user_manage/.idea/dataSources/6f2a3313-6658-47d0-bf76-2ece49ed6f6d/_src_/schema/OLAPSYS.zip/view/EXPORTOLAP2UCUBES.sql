create view EXPORTOLAP2UCUBES as
select owner, cube_name, invalid, display_name, short_description,
       description, mv_summarycode,
       irid, model              -- added for export
from olapsys.EXPORTolap1_cubes  -- changed for export
union all
select owner, cube_name, invalid, display_name, short_description,
       description, mv_summarycode,
       irid, model              -- added for export
from olapsys.EXPORTolap2_cubes  -- changed for export
with read only
