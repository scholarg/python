create view EXPORT2UCATALOGS as
select
  catalog_id,
  catalog_name,
  parent_catalog_id,
  description,
  entry_name -- added for export
from olapsys.EXPORT_catalogs
union all
select catalog_id,
  catalog_name,
  parent_catalog_id,
  description,
  entry_name -- added export
from olapsys.EXPORT2_catalogs
with read only
