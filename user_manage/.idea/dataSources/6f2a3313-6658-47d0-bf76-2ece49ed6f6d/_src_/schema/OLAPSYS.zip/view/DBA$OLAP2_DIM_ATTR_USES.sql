create view DBA$OLAP2_DIM_ATTR_USES as
select
  d.owner owner,
  d.name dimension_name,
  da.name dim_attribute_name,
  l.name level_name,
  la.name lvl_attribute_name
from olapsys.CwM2$dimension d,
     olapsys.CwM2$dimensionattribute da,
     olapsys.CwM2$levelattribute la,
     olapsys.CwM2$level l
where da.dimension_irid = d.irid and
      la.dimattr_irid = da.irid and
      la.level_irid = l.irid
with read only
