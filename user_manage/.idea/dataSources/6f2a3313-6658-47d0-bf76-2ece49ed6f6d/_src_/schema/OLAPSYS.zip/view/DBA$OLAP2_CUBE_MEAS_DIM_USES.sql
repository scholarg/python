create view DBA$OLAP2_CUBE_MEAS_DIM_USES as
select
  c.owner owner,
  c.name cube_name,
  m.name measure_name,
  d.owner dimension_owner,
  d.name dimension_name,
  null dimension_alias,
  null  default_aggr_function_use_id
from olapsys.CwM2$Cube c,
     olapsys.CwM2$Dimension d,
     olapsys.CwM2$Measure m,
     olapsys.CwM2$CubeDimensionUse cdu
where c.irid = cdu.cube_irid and
      d.irid = cdu.dimension_irid and
      m.cube_irid = c.irid
with read only
