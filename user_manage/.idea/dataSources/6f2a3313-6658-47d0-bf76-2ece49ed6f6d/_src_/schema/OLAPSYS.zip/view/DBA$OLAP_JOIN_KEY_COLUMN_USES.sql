create view DBA$OLAP_JOIN_KEY_COLUMN_USES as
SELECT
/*+ ORDERED */
  du.username owner
, d.name dimension_name
, h.hiername hierarchy_name
, l.levelname child_level_name
, tu.username table_owner
, t.name table_name
, c.name column_name
, k.keypos# position
, 'FOREIGN KEY' join_key_type
FROM
  dba_users du
, sys.obj$ d
, sys.hier$ h
, sys.hierlevel$ hl
, sys.dimlevel$ l
, sys.dimjoinkey$ k
, dba_users tu
, sys.obj$ t
, sys.col$ c
WHERE du.user_id = d.owner#
AND d.type# = 43
AND d.obj# = h.dimobj#
AND h.dimobj# = hl.dimobj#
AND h.hierid# = hl.hierid#
AND hl.dimobj# = l.dimobj#
AND hl.levelid# = l.levelid#
AND hl.dimobj# = k.dimobj#
AND hl.hierid# = k.hierid#
AND hl.joinkeyid# = k.joinkeyid#
AND k.detailobj# = t.obj#
AND k.col# = c.col#
AND t.obj# = c.obj#
AND t.owner# = tu.user_id
UNION ALL SELECT
/*+ FULL(k) */
  du.username owner
, d.name dimension_name
, h.hiername hierarchy_name
, l.levelname child_level_name
, tu.username table_owner
, t.name table_name
, c.name column_name
, k.keypos# position
, 'KEY' join_key_type
FROM
  dba_users du
, sys.obj$ d
, sys.hier$ h
, sys.hierlevel$ hl
, sys.dimlevel$ l
, sys.dimlevelkey$ k
, dba_users tu
, sys.obj$ t
, sys.col$ c
WHERE du.user_id = d.owner#
AND d.type# = 43
AND d.obj# = h.dimobj#
AND h.dimobj# = hl.dimobj#
AND h.hierid# = hl.hierid#
AND hl.dimobj# = l.dimobj#
AND hl.levelid# = l.levelid#
AND hl.joinkeyid# = 0
AND l.dimobj# = k.dimobj#
AND l.levelid# = k.levelid#
AND k.detailobj# = t.obj#
AND k.col# = c.col#
AND t.obj# = c.obj#
AND t.owner# = tu.user_id
WITH READ ONLY
