create view MRV$OLAP2_FACTTBLKEYMAPS as
select
  ftkm.owner owner,
  ftkm.cube_name cube_name,
  ftkm.dim_hier_combo_id dim_hier_combo_id,
  ftkm.dimension_owner dimension_owner,
  ftkm.dimension_name dimension_name,
  ftkm.hierarchy_name hierarchy_name,
  ftkm.level_name level_name,
  ftkm.fact_table_owner fact_table_owner,
  ftkm.fact_table_name fact_table_name,
  ftkm.column_name column_name,
  ftkm.column_data_type column_data_type,
  ftkm.column_data_length column_data_length,
  ftkm.column_data_precision column_data_precision,
  ftkm.gid_column_name gid_column_name,
  ftkm.gid_column_data_type gid_column_data_type,
  ftkm.gid_column_data_length gid_column_data_length,
  ftkm.gid_column_data_precision gid_column_data_precision,
  ftkm.dimension_keymap_type dimension_keymap_type,
  ftkm.mv_summarycode mv_summarycode,
  ftkm.column_position column_position
 from olapsys.cwm2$mrall_facttblkeymaps ftkm,
      olapsys.olap_session_objects oso
 where oso.version_id = ftkm.version_id and
       oso.id = ftkm.id
