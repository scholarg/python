create view MRV$OLAP2_CATALOG_ENTITY_USES as
select
  ceu.catalog_id catalog_id,
  ceu.entity_owner entity_owner,
  ceu.entity_name entity_name,
  ceu.child_entity_name child_entity_name
 from olapsys.cwm2$mrall_catalog_entity_uses ceu,
      olapsys.olap_session_objects oso
 where oso.version_id = ceu.version_id and
       oso.id = ceu.id
