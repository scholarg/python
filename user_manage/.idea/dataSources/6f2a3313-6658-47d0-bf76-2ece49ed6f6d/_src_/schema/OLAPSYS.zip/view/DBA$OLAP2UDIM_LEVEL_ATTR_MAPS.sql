create view DBA$OLAP2UDIM_LEVEL_ATTR_MAPS as
select attr.dim_owner owner,
       attr.dim_name dimension_name,
       attr.hierarchy_name hierarchy_name,
       attr.dim_attribute_name attribute_name,
       attr.lvl_attribute_name lvl_attribute_name,
       attr.levelname level_name,
       attr.col_owner table_owner,
       attr.col_table table_name,
       attr.col_name column_name,
       attr.dtype dtype,
       attr.data_length data_length,
       attr.data_precision data_precision,
 (case when attr.dtype = 'NUMBER' then 0
              when attr.dtype = 'DOUBLE' then 5
              when attr.dtype = 'FLOAT' then 4
              when attr.dtype = 'DATE' then 7
              when attr.dtype = 'LONG' then 3
              else 1 end) olap_api_data_type
from
     (select
         u.username                  dim_owner,
         o.name                  dim_name,
         h.hiername              hierarchy_name,
         dat.physicalname        dim_attribute_name,
         nvl(lat.name, c.name)   lvl_attribute_name,
         l.levelname             levelname,
decode(c.type#, 1, decode(c.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                 2, decode(c.scale, null,
                           decode(c.precision#, null, 'NUMBER', 'FLOAT'),
                           'NUMBER'),
                 8, 'LONG',
                 9, decode(c.charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                 12, 'DATE', 23, 'RAW', 24, 'LONG RAW',
                 69, 'ROWID',
                 96, decode(c.charsetform, 2, 'NCHAR', 'CHAR'),
                 105, 'MLSLABEL',
                 106, 'MLSLABEL',
                 112, decode(c.charsetform, 2, 'NCLOB', 'CLOB'),
                 113, 'BLOB', 114, 'BFILE', 115, 'CFILE',
                 178, 'TIME(' ||c.spare1|| ')',
                 179, 'TIME(' ||c.spare1|| ')' || ' WITH TIME ZONE',
                 180, 'TIMESTAMP(' ||c.spare1|| ')',
                 181, 'TIMESTAMP(' ||c.spare1|| ')' || ' WITH TIME ZONE',
                 182, 'INTERVAL YEAR(' ||c.spare2||') TO MONTH',
                 183, 'INTERVAL DAY(' ||c.spare2||') TO SECOND(' ||
                       c.spare1 || ')',
                 208, 'UROWID',
                 'UNDEFINED') dtype
, decode(c.length, null, 0, c.length) data_length
, decode(c.precision#, null, 0, c.precision#) data_precision,
         cu.username                 col_owner,
         ct.name                 col_table,
         c.name                  col_name
      from
         dba_users               u,
         sys.obj$                o,
         sys.dim$                d,
         sys.dimlevel$           l,
         sys.dimattr$            a,
         sys.hierlevel$          hl,
         sys.hier$               h,
         sys.col$                c,
         sys.obj$                ct,
         dba_users               cu,
         cwm$levelattribute      lat,
         cwm$level               lvl,
         cwm$itemuse             iu1,
         cwm$itemuse             iu2,
         cwm$dimensionattribute  dat
      where u.user_id = o.owner# and
            o.type# = 43 and
            o.obj# = d.obj# and
            d.obj# = l.dimobj# and
            d.obj# = dat.itemcontainer_irid and
            d.obj# = h.dimobj# and
            d.obj# = hl.dimobj# and
            h.hierid# = hl.hierid# and
            hl.levelid# = l.levelid# and
            l.dimobj# = a.dimobj# and
            l.levelid# = a.levelid# and
            a.detailobj# = c.obj# and
            a.col# = c.col# and
            c.obj# = ct.obj# and
            ct.owner# = cu.user_id and
            c.obj# = lat.type_irid and
            c.name = lat.physicalname and
            lvl.dimension_irid = l.dimobj# and
            lat.itemcontainer_irid = lvl.irid and
            lat.irid = iu2.mappable_irid and
            iu2.operation_irid_1 = iu1.operation_irid and
            iu1.mappable_irid = dat.irid
     ) attr
union all
select attr1.dim_owner owner,
       attr1.dim_name dimension_name,
       null hierarchy_name,
       attr1.dim_attribute_name attribute_name,
       attr1.lvl_attribute_name lvl_attribute_name,
       attr1.levelname level_name,
       attr1.col_owner table_owner,
       attr1.col_table table_name,
       attr1.col_name column_name,
       attr1.dtype dtype,
       attr1.data_length data_length,
       attr1.data_precision data_precision,
 (case when attr1.dtype = 'NUMBER' then 0
              when attr1.dtype = 'DOUBLE' then 5
              when attr1.dtype = 'FLOAT' then 4
              when attr1.dtype = 'DATE' then 7
              when attr1.dtype = 'LONG' then 3
              else 1 end) olap_api_data_type
from
     (select
         u.username                  dim_owner,
         o.name                  dim_name,
         dat.physicalname        dim_attribute_name,
         nvl(lat.name, c.name)   lvl_attribute_name,
         l.levelname             levelname,
decode(c.type#, 1, decode(c.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                 2, decode(c.scale, null,
                           decode(c.precision#, null, 'NUMBER', 'FLOAT'),
                           'NUMBER'),
                 8, 'LONG',
                 9, decode(c.charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                 12, 'DATE', 23, 'RAW', 24, 'LONG RAW',
                 69, 'ROWID',
                 96, decode(c.charsetform, 2, 'NCHAR', 'CHAR'),
                 105, 'MLSLABEL',
                 106, 'MLSLABEL',
                 112, decode(c.charsetform, 2, 'NCLOB', 'CLOB'),
                 113, 'BLOB', 114, 'BFILE', 115, 'CFILE',
                 178, 'TIME(' ||c.spare1|| ')',
                 179, 'TIME(' ||c.spare1|| ')' || ' WITH TIME ZONE',
                 180, 'TIMESTAMP(' ||c.spare1|| ')',
                 181, 'TIMESTAMP(' ||c.spare1|| ')' || ' WITH TIME ZONE',
                 182, 'INTERVAL YEAR(' ||c.spare2||') TO MONTH',
                 183, 'INTERVAL DAY(' ||c.spare2||') TO SECOND(' ||
                       c.spare1 || ')',
                 208, 'UROWID',
                 'UNDEFINED') dtype
, decode(c.length, null, 0, c.length) data_length
, decode(c.precision#, null, 0, c.precision#) data_precision,
         cu.username                 col_owner,
         ct.name                 col_table,
         c.name                  col_name,
         l.dimobj#               l_dimobj,
         l.levelid#              l_levelid
      from
         dba_users               u,
         sys.obj$                o,
         sys.dim$                d,
         sys.dimlevel$           l,
         sys.dimattr$            a,
         sys.col$                c,
         sys.obj$                ct,
         dba_users               cu,
         cwm$levelattribute      lat,
         cwm$level               lvl,
         cwm$itemuse             iu1,
         cwm$itemuse             iu2,
         cwm$dimensionattribute  dat
      where u.user_id = o.owner# and
            o.type# = 43 and
            o.obj# = d.obj# and
            d.obj# = l.dimobj# and
            d.obj# = dat.itemcontainer_irid and
            l.dimobj# = a.dimobj# and
            l.levelid# = a.levelid# and
            a.detailobj# = c.obj# and
            a.col# = c.col# and
            c.obj# = ct.obj# and
            ct.owner# = cu.user_id and
            c.obj# = lat.type_irid and
            c.name = lat.physicalname and
            lvl.dimension_irid = l.dimobj# and
            lat.itemcontainer_irid = lvl.irid and
            lat.irid = iu2.mappable_irid and
            iu2.operation_irid_1 = iu1.operation_irid and
            iu1.mappable_irid = dat.irid
     ) attr1,
     (select dl1.dimobj# l_dimobj,
             dl1.levelid# l_levelid
       from sys.dimlevel$ dl1
       where to_char(dl1.dimobj#) || '_' || to_char(dl1.levelid#) not in
        (select to_char(hl.dimobj#) || '_' || to_char(hl.levelid#)
         from sys.hierlevel$ hl)
     ) nohierlvl
     where nohierlvl.l_dimobj = attr1.l_dimobj and
           nohierlvl.l_levelid = attr1.l_levelid
union all
select owner, dimension_name, hierarchy_name, attribute_name,
       lvl_attribute_name, level_name,
       table_owner, table_name, column_name, dtype, data_length,
       data_precision, olap_api_data_type
from olapsys.dba$olap2_dim_level_attr_maps
with read only
