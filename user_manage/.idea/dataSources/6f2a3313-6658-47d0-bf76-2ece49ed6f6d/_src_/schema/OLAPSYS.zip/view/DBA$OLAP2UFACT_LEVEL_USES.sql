create view DBA$OLAP2UFACT_LEVEL_USES as
select a.owner owner,
       a.cube_name cube_name,
       a.dimension_owner dimension_owner,
       a.dimension_name dimension_name,
       a.dimension_alias dimension_alias,
       b.hierarchy_name hierarchy_name,
       0  dim_hier_combo_id,
       a.level_name level_name,
       a.fact_table_owner fact_table_owner,
       a.fact_table_name fact_table_name,
       fk.column_name column_name,
       fk.position position,
       'LL' dimension_keymap_type,
       a.foreign_key_name
from olapsys.dba$olap1_fact_level_uses a,
     dba_olap_dim_hierarchies b,
     (select u.username table_owner,
             t.name table_name,
             c.name key_name,
             col.name column_name,
             ccol.pos# position
      from
         dba_users u,
         sys.obj$ t,
         sys.con$ c,
         sys.cdef$ cd,
         sys.col$ col,
         sys.ccol$ ccol
      where
         u.user_id = c.owner# and
         c.con# = cd.con# and
         cd.con# = ccol.con# and
         cd.obj# = t.obj# and
         ccol.intcol# = col.intcol# and
         col.obj# = t.obj# and
         cd.type# in (2,3,4) and
         t.type# in (2,4)) fk
where a.dimension_name = b.dimension_name (+)
  and a.dimension_owner = b.owner (+)
  and a.fact_table_owner = fk.table_owner
  and a.fact_table_name = fk.table_name
  and a.foreign_key_name = fk.key_name
union all
select owner, cube_name, dimension_owner, dimension_name,
       dimension_alias, hierarchy_name, dim_hier_combo_id,
       level_name, fact_table_owner, fact_table_name, column_name,
       position, dimension_keymap_type, foreign_key_name
from olapsys.dba$olap2_fact_level_uses
with read only
