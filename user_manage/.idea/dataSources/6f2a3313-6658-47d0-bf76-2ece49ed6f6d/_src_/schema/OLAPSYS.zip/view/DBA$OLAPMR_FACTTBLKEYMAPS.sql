create view DBA$OLAPMR_FACTTBLKEYMAPS as
select a.owner owner,
       a.cube_name cube_name,
       a.dimension_owner dimension_owner,
       a.dimension_name dimension_name,
       a.level_name level_name,
       a.fact_table_owner fact_table_owner,
       a.fact_table_name fact_table_name,
       fk.column_name column_name,
       fk.position column_position,
       b.mv_summarycode mv_summary_code
from olapsys.dba$olap1_fact_level_uses a,
     olapsys.dba$olap1_cubes b,
     (select u.username table_owner,
             t.name table_name,
             c.name key_name,
             col.name column_name,
             ccol.pos# position
      from
         dba_users u,
         sys.obj$ t,
         sys.con$ c,
         sys.cdef$ cd,
         sys.col$ col,
         sys.ccol$ ccol
      where
         u.user_id = c.owner# and
         c.con# = cd.con# and
         cd.con# = ccol.con# and
         cd.obj# = t.obj# and
         ccol.intcol# = col.intcol# and
         col.obj# = t.obj# and
         cd.type# in (2,3,4) and
         t.type# in (2,4)) fk
where
  a.fact_table_owner = fk.table_owner
  and a.fact_table_name = fk.table_name
  and a.foreign_key_name = fk.key_name
  and a.owner = b.owner
  and a.cube_name = b.cube_name
with read only
