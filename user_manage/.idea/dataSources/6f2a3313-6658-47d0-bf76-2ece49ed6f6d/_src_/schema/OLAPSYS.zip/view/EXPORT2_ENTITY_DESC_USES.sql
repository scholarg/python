create view EXPORT2_ENTITY_DESC_USES as
select
 ce.classification_irid descriptor_id,
 cub.owner entity_owner,
 cub.name entity_name,
 null child_entity_name,
 null secondary_child_entity_name,
 c.name classification_name,  -- added for export
 ce.name entry_name           -- added for export
from /* CUBE2 */
  cwm$classification c,
  cwm$classificationentry ce,
  cwm$classificationtype cty,
  cwm2$cube cub
where cty.irid = c.classificationtype_irid and
      cty.name <> 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'CUBE2' and
      ce.element_irid = cub.irid
UNION ALL select
 ce.classification_irid descriptor_id,
 cub.owner entity_owner,
 cub.name entity_name,
 meas.name child_entity_name,
 null secondary_child_entity_name,
 c.name classification_name,  -- added for export
 ce.name entry_name           -- added for export
from /* MEASURE2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$cube cub,
 cwm2$measure meas
where cty.irid = c.classificationtype_irid and
      cty.name <> 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'MEASURE2' and
      ce.element_irid = meas.irid and
      meas.cube_irid = cub.irid
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 dat.name child_entity_name,
 null secondary_child_entity_name,
 c.name classification_name,  -- added for export
 ce.name entry_name           -- added for export
from /* DIMENSION ATTRIBUTE2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$dimensionattribute dat
where cty.irid = c.classificationtype_irid and
      cty.name <> 'ORACLE_OLAP2_CATALOG' and
      c.irid = ce.classification_irid and
      ce.name = 'DIMENSION ATTRIBUTE2' and
      ce.element_irid = dat.irid and
      dat.dimension_irid = dim.irid
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 lvl.name child_entity_name,
 lat.name secondary_child_entity_name,
 c.name classification_name,  -- added for export
 ce.name entry_name           -- added for export
from /* LEVEL ATTRIBUTE2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$dimensionattribute dat,
 cwm2$levelattribute lat,
 cwm2$level lvl
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.name = 'LEVEL ATTRIBUTE2' and
      ce.element_irid = lat.irid and
      lat.dimattr_irid = dat.irid and
      dat.dimension_irid = dim.irid and
      lvl.irid = lat.level_irid
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 ce.secondary_object_name child_entity_name,
 null secondary_child_entity_name,
 c.name classification_name,  -- added for export
 ce.name entry_name           -- added for export
from /* DIMENSION2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.name  = 'DIMENSION2' and
      ce.element_irid = dim.irid
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 hier.name child_entity_name,
 null secondary_child_entity_name,
 c.name classification_name,  -- added for export
 ce.name entry_name           -- added for export
from /* HIERARCHY2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$hierarchy hier
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.name  = 'HIERARCHY2' and
      dim.irid = hier.dimension_irid and
      ce.element_irid = hier.irid
UNION ALL select
 ce.classification_irid descriptor_id,
 dim.owner entity_owner,
 dim.name entity_name,
 lvl.name child_entity_name,
 null secondary_child_entity_name,
 c.name classification_name,  -- added for export
 ce.name entry_name           -- added for export
from /* LEVEL2 */
 cwm$classification c,
 cwm$classificationentry ce,
 cwm$classificationtype cty,
 cwm2$dimension dim,
 cwm2$level lvl
where cty.irid = c.classificationtype_irid and
      cty.name not in ('ORACLE_OLAP2_CATALOG',
                       'ORACLE_OLAP_CATALOG') and
      c.irid = ce.classification_irid and
      ce.name  = 'LEVEL2' and
      dim.irid = lvl.dimension_irid and
      ce.element_irid = lvl.irid
with read only
