create view DBA$OLAP_FUNCTIONS as
SELECT
  f.name function_name
, f.description description
FROM
  cwm$function f
WITH READ ONLY
