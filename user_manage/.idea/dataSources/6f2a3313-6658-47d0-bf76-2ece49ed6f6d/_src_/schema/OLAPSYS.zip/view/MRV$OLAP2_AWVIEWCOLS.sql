create view MRV$OLAP2_AWVIEWCOLS as
select
 VIEW_OWNER,
 VIEW_NAME,
 COLUMN_NAME,
 AWOBJECT
 from olapsys.cwm2$mrall_awviewcols
