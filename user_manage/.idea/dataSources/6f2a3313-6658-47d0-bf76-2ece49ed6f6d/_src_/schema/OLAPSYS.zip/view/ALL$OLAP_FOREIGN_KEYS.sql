create view ALL$OLAP_FOREIGN_KEYS as
SELECT
  u.username owner
, t.name table_name
, c.name foreign_key_name
, decode(bitand(cd.defer,32),32, 'Y', 'N') is_rely
FROM
  dba_users u
, sys.obj$ t
, sys.con$ c
, sys.cdef$ cd
WHERE u.user_id = t.owner#
AND t.type# IN (2,4) /* table, view */
AND t.obj# = cd.obj#
AND cd.con# = c.con#
AND cd.type# = 4 /* referential */
AND (   t.owner# = UID
     OR t.obj# IN
       (SELECT obj# FROM sys.objauth$
        WHERE (   grantee# = UID
               OR grantee# IN
                 (SELECT privilege#
                  FROM sys.sysauth$
                  WHERE privilege# > 0
                  START WITH grantee# = UID
                  CONNECT BY PRIOR privilege# = grantee#)))
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
WITH READ ONLY
