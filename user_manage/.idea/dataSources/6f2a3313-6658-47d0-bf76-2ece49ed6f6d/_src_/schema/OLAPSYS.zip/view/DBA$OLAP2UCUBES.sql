create view DBA$OLAP2UCUBES as
select owner, cube_name, invalid, display_name, short_description,
       description, mv_summarycode
from olapsys.dba$olap1_cubes
union all
select owner, cube_name, invalid, display_name, short_description,
       description, mv_summarycode
from olapsys.dba$olap2_cubes
with read only
