create view MRV$OLAP1_POP_DIMENSIONS as
select
  dim.irid id
FROM
  dba_users u,
  sys.obj$ o,
  sys.dim$ d,
  cwm$dimension dim
WHERE u.user_id = o.owner# and
      o.obj# = d.obj# and
      d.obj# = dim.irid and
      cwm$util.dimension_tables_visible(d.obj#) = 'Y'
