create view MRAC_OLAP2_AWS_V as
select "OWNER","AW" from olapsys.MRAC_OLAP2_AWS_T
