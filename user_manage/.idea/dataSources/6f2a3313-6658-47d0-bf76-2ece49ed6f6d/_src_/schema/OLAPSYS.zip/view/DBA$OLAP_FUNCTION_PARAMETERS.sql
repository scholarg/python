create view DBA$OLAP_FUNCTION_PARAMETERS as
SELECT
  f.name function_name
, p.name parameter_name
, d.name data_type
, p.shortdescription parameter_type
, p.length length
, p.precision precision
, p.scale scale
, p.input_fk_seq position
FROM
  cwm$function f
, cwm$parameter p
, cwm$domain d
WHERE f.irid = p.operation_irid
AND p.type_irid = d.irid (+)
WITH READ ONLY
