create view DBA$OLAP2_AGGREGATION_USES as
select
  aggop.owner owner,
  aggop.cube_name cube_name,
  aggop.dimension_owner dimension_owner,
  aggop.dimension_name dimension_name,
  aggop.hierarchy_name hierarchy_name,
  aggop.dim_hier_combo_id dim_hier_combo_id,
  aggop.aggregation_name aggregation_name,
  aggop.aggregation_order aggregation_order,
  aggwb.table_owner table_owner,
  aggwb.table_name table_name,
  aggwb.column_name column_name
from olapsys.dba$olap2_agg_operator_uses aggop,
     olapsys.dba$olap2_agg_weightby_uses aggwb
where aggop.owner = aggwb.owner (+) and
      aggop.cube_name = aggwb.cube_name (+) and
      aggop.dimension_owner = aggwb.dimension_owner (+) and
      aggop.dimension_name = aggwb.dimension_name (+) and
      aggop.hierarchy_name = aggwb.hierarchy_name (+)
with read only
