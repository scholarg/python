create view DBA$OLAP2_MR_MEASDIMVIEW as
select
 owner || '.' || cube_name || '.' || measure_name measid,
 display_name display_name,
 description description
from olapsys.dba$olap2ucube_measures
with read only
