create view DBA$OLAPMR_DIM_ATTRIBUTES as
SELECT
  u.username                  owner,
  o.name                  dimension_name,
  att.physicalname        attribute_name,
  att.displayname         display_name,
  att.description         short_description,
  att.description         description,
  ce.classification_irid  desc_id
FROM
  dba_users               u,
  sys.obj$                o,
  cwm$dimensionattribute  att,
  cwm$classificationentry ce
WHERE o.type# = 43 AND
      u.user_id = o.owner# AND
      att.itemcontainer_irid = o.obj# AND
      att.irid = ce.element_irid(+) and
      ce.name (+) = 'DIMENSION ATTRIBUTE'
WITH READ ONLY
