create view MRV$OLAP2_DIM_ATTRIBUTES as
select
  da.owner owner,
  da.dimension_name dimension_name,
  da.attribute_name attribute_name,
  da.display_name display_name,
  da.shortdescription short_description,
  da.description description,
  da.desc_id desc_id
 from olapsys.cwm2$mrall_dim_attributes da,
      olapsys.olap_session_objects oso
 where oso.version_id = da.version_id and
       oso.id = da.id
