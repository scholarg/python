create view DBA$OLAP_FUNCTION_USAGES as
SELECT
  u.irid function_usage_id
, f.name function_name
FROM
  cwm$function f
, cwm$functionuse u
WHERE f.irid = u.function_irid
WITH READ ONLY
