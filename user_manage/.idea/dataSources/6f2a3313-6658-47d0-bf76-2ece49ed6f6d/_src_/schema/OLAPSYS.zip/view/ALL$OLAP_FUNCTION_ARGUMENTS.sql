create view ALL$OLAP_FUNCTION_ARGUMENTS as
SELECT
/*+ ORDERED */
  a.functionuse_irid function_usage_id
, p.name parameter_name
, u.username entity_owner
, t.name entity_name
, c.name child_entity_name
, 'COLUMN' entity_type
FROM
  cwm$parameter p
, cwm$argument a
, sys.col$ c
, sys.obj$ t
, dba_users u
WHERE a.parameter_irid = p.irid
AND a.element_irid = c.obj#
AND a.secondary_object_name = c.name
AND t.obj# = c.obj#
AND t.type# IN (2,4)
AND t.owner# = u.user_id
AND (   t.owner# = UID
     OR t.obj# IN
       (SELECT obj# FROM sys.objauth$
        WHERE (   grantee# = UID
               OR grantee# IN
                 (SELECT privilege#
                  FROM sys.sysauth$
                  WHERE privilege# > 0
                  START WITH grantee# = UID
                  CONNECT BY PRIOR privilege# = grantee#)))
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
WITH READ ONLY
