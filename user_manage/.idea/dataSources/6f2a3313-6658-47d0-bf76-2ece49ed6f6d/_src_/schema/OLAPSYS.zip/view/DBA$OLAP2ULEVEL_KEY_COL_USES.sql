create view DBA$OLAP2ULEVEL_KEY_COL_USES as
select distinct lkcu.owner owner,
       lkcu.dimension_name dimension_name,
       dhl.hierarchy_name hierarchy_name,
       lkcu.level_name child_level_name,
       lkcu.table_owner table_owner,
       lkcu.table_name table_name,
       lkcu.column_name column_name,
       lkcu.position position
from
    (select u.username owner,
            d.name dimension_name,
            l.levelname level_name,
            c.name column_name,
            k.keypos# position,
            tu.username table_owner,
            tn.name table_name
      from dba_users u,
           sys.obj$ d,
           sys.dimlevel$ l,
           sys.dimlevelkey$ k,
           sys.col$ c,
           sys.obj$ tn,
           dba_users tu,
           olapsys.cwm$level lev
      where u.user_id = d.owner# and
            d.type# = 43 and
            d.obj# = l.dimobj# and
            l.dimobj# = k.dimobj# and
            l.levelid# = k.levelid# and
            k.detailobj# = c.obj# and
            k.col# = c.col# and
            tn.obj# = c.obj# and
            tu.user_id = tn.owner# and
            lev.dimension_irid = l.dimobj# and
            lev.physicalname = l.levelname
      ) lkcu,
    (select u.username  dim_owner,
           o.name  dim_name,
           h.hiername  hierarchy_name,
           dl.levelname level_name
      from dba_users u,
           sys.obj$ o,
           sys.dim$ d,
           sys.dimlevel$ dl,
           sys.hier$ h,
           sys.hierlevel$ hl,
           olapsys.cwm$level lev
      where u.user_id = o.owner# and
            o.type# = 43 and
            o.obj# = d.obj# and
            d.obj# = dl.dimobj# and
            d.obj# = h.dimobj# and
            h.dimobj# = hl.dimobj# and
            h.hierid# = hl.hierid# and
            hl.levelid# = dl.levelid# and
            lev.dimension_irid = dl.dimobj# and
            lev.physicalname = dl.levelname
            ) dhl
    where  lkcu.owner = dhl.dim_owner (+) and
           lkcu.dimension_name = dhl.dim_name (+) and
           lkcu.level_name = dhl.level_name (+)
UNION ALL
select owner, dimension_name, hierarchy_name, child_level_name,
       table_owner, table_name, column_name, position
from olapsys.dba$olap2_level_key_col_uses
with read only
