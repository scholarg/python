create view DBA$OLAP_DESCRIPTORS as
SELECT
  c.irid descriptor_id
, c.name descriptor_value
, cty.name descriptor_type
, c.description description
FROM
  cwm$classification c
, cwm$classificationtype cty
WHERE cty.irid = c.classificationtype_irid
AND cty.name <> 'ORACLE_OLAP_CATALOG'
WITH READ ONLY
