create view DBA$OLAP2_DIM_ATTRIBUTES as
select
  d.owner owner,
  d.name dimension_name,
  da.name attribute_name,
  da.displayname display_name,
  da.shortdescription short_description,
  da.description description,
  ce.classification_irid desc_id
from olapsys.CwM2$dimension d,
     olapsys.CwM2$dimensionattribute da,
     olapsys.cwm$classificationentry ce
where da.dimension_irid = d.irid and
      da.irid = ce.element_irid (+) and
      ce.name (+) = 'DIMENSION ATTRIBUTE2'
with read only
