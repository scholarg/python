create view ALL$OLAP_CUBE_MEASURES as
SELECT
  sch.physicalname owner
, cub.physicalname cube_name
, msr.physicalname measure_name
, msr.displayname display_name
, msr.description description
FROM
  dba_users u
, cwm$model sch
, cwm$cube cub
, cwm$measure msr
WHERE u.username = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND (    cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
AND cub.irid = msr.itemcontainer_irid
WITH READ ONLY
