create view ALL$AW_LOAD_CUBES as
select c.owner cube_owner,
         c.name cube_name,
         cl.name load_name,
         clt.name load_type
  from
    cwm2$awcubeload cl,
    cwm2$awcubeloadtype clt,
    cwm2$cube c
  where
    cl.loadtype_irid = clt.irid and
    cl.cube_irid = c.irid and
    cl.version_id = 'CWM2' and
    (c.invalid = 'N' or c.invalid = 'O') and
    (cwm2$security.fact_table_visible(c.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47)))
 union all
  select sch.physicalname cube_owner,
         c.physicalname cube_name,
         cl.name load_name,
         clt.name load_type
  from
    cwm2$awcubeload cl,
    cwm2$awcubeloadtype clt,
    cwm$cube c,
    cwm$model sch
  where
   cl.loadtype_irid = clt.irid and
   cl.cube_irid = c.irid and
   cl.version_id = 'CWM' and
   sch.irid = c.datamodel_irid and
   (cwm$util.fact_table_visible(c.irid) = 'Y'
      OR EXISTS (select null from v$enabledprivs
                 where priv_number in (-47)))
with read only
