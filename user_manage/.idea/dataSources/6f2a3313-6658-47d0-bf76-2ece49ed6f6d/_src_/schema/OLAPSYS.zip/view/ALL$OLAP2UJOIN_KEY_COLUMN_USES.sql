create view ALL$OLAP2UJOIN_KEY_COLUMN_USES as
SELECT
  u.username owner
, d.name dimension_name
, h.hiername hierarchy_name
, l.levelname child_level_name
, tu.username table_owner
, t.name table_name
, c.name column_name
, k.keypos# position
, 'FOREIGN KEY' join_key_type
FROM
  dba_users u
, sys.obj$ d
, sys.hier$ h
, sys.hierlevel$ hl
, sys.dimlevel$ l
, sys.dimjoinkey$ k
, dba_users tu
, sys.obj$ t
, sys.col$ c
, olapsys.cwm$level lev
WHERE u.user_id = d.owner#
AND d.type# = 43 /* DIMENSION */
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
AND d.obj# = h.dimobj#
AND h.dimobj# = hl.dimobj#
AND h.hierid# = hl.hierid#
AND hl.dimobj# = l.dimobj#
AND hl.levelid# = l.levelid#
AND hl.dimobj# = k.dimobj#
AND hl.hierid# = k.hierid#
AND hl.joinkeyid# = k.joinkeyid#
AND k.detailobj# = t.obj#
AND k.col# = c.col#
AND t.obj# = c.obj#
AND t.owner# = tu.user_id
AND lev.dimension_irid = l.dimobj#
AND lev.physicalname = l.levelname
UNION ALL SELECT /*+ORDERED*/
  u.username owner
, d.name dimension_name
, h.hiername hierarchy_name
, l.levelname child_level_name
, tu.username table_owner
, t.name table_name
, c.name column_name
, k.keypos# position
, 'KEY' join_key_type
FROM
  dba_users u
, sys.obj$ d
, sys.hier$ h
, sys.hierlevel$ hl
, sys.dimlevel$ l
, sys.dimlevelkey$ k
, dba_users tu
, sys.obj$ t
, sys.col$ c
, olapsys.cwm$level lev
WHERE u.user_id = d.owner#
AND d.type# = 43 /* DIMENSION */
AND (   cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
AND d.obj# = h.dimobj#
AND h.dimobj# = hl.dimobj#
AND h.hierid# = hl.hierid#
AND hl.dimobj# = l.dimobj#
AND hl.levelid# = l.levelid#
AND hl.joinkeyid# = 0
AND l.dimobj# = k.dimobj#
AND l.levelid# = k.levelid#
AND k.detailobj# = t.obj#
AND k.col# = c.col#
AND t.obj# = c.obj#
AND t.owner# = tu.user_id
AND lev.dimension_irid = l.dimobj#
AND lev.physicalname = l.levelname
union all
select owner, dimension_name, hierarchy_name, child_level_name, table_owner,
       table_name, column_name, position, join_key_type
from olapsys.all$olap2_join_key_column_uses
with read only
