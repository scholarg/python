create view DBA$OLAP_CATALOGS as
SELECT
  c.irid catalog_id
, c.name catalog_name
, cp.irid parent_catalog_id
, c.description description
FROM
  cwm$classification c
, cwm$classification cp
, cwm$classificationtype cty
, cwm$classificationentry ce
WHERE cty.irid = c.classificationtype_irid
AND cty.name = 'ORACLE_OLAP_CATALOG'
AND c.irid = ce.element_irid
AND ce.name = 'CATALOG'
AND ce.classification_irid = cp.irid
UNION ALL SELECT
  c.irid catalog_id
, c.name catalog_name
, null parent_catalog_id
, c.description description
FROM
  cwm$classification c
, cwm$classificationtype cty
WHERE cty.irid = c.classificationtype_irid
AND cty.name = 'ORACLE_OLAP_CATALOG'
AND NOT EXISTS
    (SELECT null
    FROM cwm$classificationentry ce
    WHERE ce.name = 'CATALOG'
    AND ce.element_irid = c.irid)
WITH READ ONLY
