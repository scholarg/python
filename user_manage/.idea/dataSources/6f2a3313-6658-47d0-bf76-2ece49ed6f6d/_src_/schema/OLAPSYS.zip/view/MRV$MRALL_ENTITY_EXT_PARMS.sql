create view MRV$MRALL_ENTITY_EXT_PARMS as
select
 eep.DESCRIPTOR_ID,
 eep.DESCRIPTOR_NAME,
 eep.ENTITY_OWNER,
 eep.ENTITY_NAME,
 eep.CHILD_ENTITY_NAME,
 eep.SECONDARY_CHILD_ENTITY_NAME,
 eep.PARAMETER_NAME,
 eep.PARAMETER_VALUE,
 eep.PARAMETER_VALUE2,
 eep.PARAMETER_VALUE3,
 eep.PARAMETER_VALUE4,
 eep.POSITION
from olapsys.cwm2$mrall_entity_ext_parms eep,
     olapsys.olap_session_objects oso
 where oso.version_id = eep.version_id and
       oso.id = eep.id
