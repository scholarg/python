create view ALL$OLAP2UDIMENSIONS as
select mrd.owner owner,
       mrd.dimension_name dimension_name,
       mrd.plural_name plural_name,
       mrd.display_name display_name,
       mrd.short_description short_description,
       mrd.description description,
       mrd.default_display_hierarchy default_display_hierarchy,
       decode(mrd.status, 5, 'Y', 'N') invalid,
       'HIER' dimension_type
from olapsys.all$olapmr_dimensions mrd
union all
select owner, dimension_name, plural_name, display_name, short_description,
       description, default_display_hierarchy, invalid, dimension_type
from olapsys.all$olap2_dimensions
with read only
